package com.lts.autowiring;

import org.springframework.stereotype.Component;

@Component
public class Triangle implements Shape{

	@Override
	public void CalculateArea(int x, int y) {
		System.out.println("Tri="+(0.5)*x*y);
	}

}
