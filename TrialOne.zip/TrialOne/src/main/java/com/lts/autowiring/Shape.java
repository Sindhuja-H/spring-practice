package com.lts.autowiring;

public interface Shape {
	void CalculateArea(int x, int y);
}
